import 'package:flutter/material.dart';
import '../services/storage_service.dart';

class AuthProvider with ChangeNotifier {
  final StorageService _storageService;
  bool _isLoggedIn = false;
  String? _userName;
  String? _userEmail;

  AuthProvider(this._storageService);

  bool get isLoggedIn => _isLoggedIn;
  String get userName => _userName ?? "John Doe";
  String get userEmail => _userEmail ?? "johndoe";

  Future<void> loadUser() async {
    _isLoggedIn = _storageService.isLoggedIn();
    if (_isLoggedIn) {
      _userName = _storageService.getUserName();
      _userEmail = _storageService.getUserEmail();
    }
    notifyListeners();
  }

  Future<bool> login(String email, String password) async {
    final storedEmail = _storageService.getUserEmail();
    final storedPassword = _storageService.getUserPassword();

    if (email == storedEmail && password == storedPassword) {
      _isLoggedIn = true;
      _userName = _storageService.getUserName();
      _userEmail = storedEmail;
      await _storageService.setLoggedIn(true);
      notifyListeners();
      return true;
    }
    return false;
  }

  Future<void> signup(String name, String email, String password) async {
    await _storageService.setUserName(name);
    await _storageService.setUserEmail(email);
    await _storageService.setUserPassword(password);
    await _storageService.setLoggedIn(true);

    _isLoggedIn = true;
    _userName = name;
    _userEmail = email;
    notifyListeners();
  }

  Future<void> logout() async {
    await _storageService.setLoggedIn(false);
    _isLoggedIn = false;
    _userName = null;
    _userEmail = null;
    notifyListeners();
  }

  bool isAccountCreated() {
    return _storageService.getUserEmail() != null;
  }

  String? getPasswordHint() {
    return _storageService.getUserPassword();
  }
}