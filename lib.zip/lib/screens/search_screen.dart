import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/storage_service.dart';
import 'ResultsPage.dart';

class SearchPage extends StatefulWidget {
  final String? initialQuestion;
  const SearchPage({super.key, this.initialQuestion});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  late TextEditingController _controller;
  final StorageService _storageService = StorageService();

  final Map<String, double> _religionData = {
    "Hindu": 40,
    "Christian": 35,
    "Islam": 25
  };

  List<String> _flashcards = [];
  int? _selectedReligionIndex;

  @override
  void initState() {
    super.initState();
    _storageService.init();
    _controller = TextEditingController(text: widget.initialQuestion ?? "");
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// Mocked backend call using the sample JSON you provided
  Future<List<String>> _fetchResultsFromBackend(String query) async {
    final mockData = {
      "question": query,
      "summary": """
🔹 Relevant Shlokas:

(Since no verses are provided, I will use my knowledge of the Bhagavad Gita to answer the question.)

📖 (Equivalent to BG 2.47): You have a right to perform your actions, but you are not entitled to the fruits of the actions...

📖 (Equivalent to BG 16.1-4): Fearlessness, purity of heart, perseverance in the pursuit of knowledge...

🔹 Explanation:

🔹 Overview
The Bhagavad Gita doesn't define "evil" in terms of a singular entity or being...

🔹 Core Message / Takeaway
The Bhagavad Gita teaches that "evil" arises from ignorance, attachment, and selfish desires...
"""
    };

    // Return the summary split into lines for the UI
    return List<String>.from(
        mockData["summary"]!.split("\n").where((line) => line.trim().isNotEmpty));
  }

  /// 🔹 Called when pressing "Ask"
  void _onSearchAction(String query) async {
    if (query.trim().isEmpty) return;

    // Fetch results from "backend" (mocked for now)
    final results = await _fetchResultsFromBackend(query);

    setState(() {
      _flashcards = results;
      _selectedReligionIndex = null;
    });

    // Store in recent searches
    final recent = _storageService.getRecentSearches();
    recent.remove(query);
    recent.insert(0, query);
    await _storageService.setRecentSearches(recent.take(10).toList());
  }

  Future<void> _bookmark(String query) async {
    if (query.trim().isEmpty) return;
    final bookmarks = _storageService.getBookmarks();
    if (!bookmarks.contains(query)) {
      bookmarks.add(query);
      await _storageService.setBookmarks(bookmarks);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text("Bookmarked")));
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text("Already Bookmarked")));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = context.watch<ThemeProvider>().isDarkMode;
    final primaryColor = Theme.of(context).colorScheme.primary;
    final onSurfaceColor = Theme.of(context).colorScheme.onSurface;

    return Scaffold(
      appBar: AppBar(
          title: Text("Search",
              style: GoogleFonts.merriweather(fontWeight: FontWeight.bold))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: TextStyle(color: onSurfaceColor),
                    decoration: InputDecoration(
                      hintText: "Ask your question...",
                      hintStyle:
                      TextStyle(color: onSurfaceColor.withOpacity(0.6)),
                      prefixIcon: Icon(Icons.search, color: primaryColor),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                          borderSide: BorderSide.none),
                      filled: true,
                      fillColor: isDarkMode ? Colors.grey[800] : Colors.brown[50],
                    ),
                    onSubmitted: _onSearchAction,
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () => _onSearchAction(_controller.text),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 15),
                  ),
                  child: const Text("Ask", style: TextStyle(fontSize: 16)),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () => _bookmark(_controller.text),
              icon: const Icon(Icons.bookmark_add),
              label: const Text("Bookmark this query"),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryColor,
                foregroundColor: Colors.white,
                padding:
                const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              ),
            ),
            const SizedBox(height: 24),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Religious Insights:",
                style: GoogleFonts.merriweather(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: onSurfaceColor,
                ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(height: 220, child: _buildPieChart(isDarkMode)),
            const SizedBox(height: 20),
            _buildReligionCard(isDarkMode),
          ],
        ),
      ),
    );
  }

  Widget _buildPieChart(bool isDarkMode) {
    final religionColors = {
      "Hindu": Colors.orange,
      "Christian": Colors.blue,
      "Islam": Colors.green
    };

    return PieChart(
      PieChartData(
        sections: List.generate(_religionData.length, (i) {
          final entry = _religionData.entries.elementAt(i);
          return PieChartSectionData(
            value: entry.value,
            color: religionColors[entry.key] ?? Colors.grey,
            radius: _selectedReligionIndex == i ? 90 : 70,
            title: entry.key,
            titleStyle: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: isDarkMode ? Colors.white : Colors.black,
            ),
          );
        }),
        sectionsSpace: 4,
        centerSpaceRadius: 0,
        pieTouchData: PieTouchData(
          touchCallback: (_, response) {
            if (response != null && response.touchedSection != null) {
              final idx = response.touchedSection!.touchedSectionIndex;
              if (idx >= 0) {
                setState(() {
                  _selectedReligionIndex = idx;
                });
              }
            }
          },
        ),
      ),
    );
  }

  Widget _buildReligionCard(bool isDarkMode) {
    if (_selectedReligionIndex == null || _flashcards.isEmpty) {
      return Center(
        child: Text(
          "Select a religion from the chart above",
          style: TextStyle(
              color: Theme.of(context)
                  .colorScheme
                  .onSurface
                  .withOpacity(0.7)),
        ),
      );
    }

    final String religionName =
    _religionData.keys.toList()[_selectedReligionIndex!];

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        splashColor:
        Theme.of(context).colorScheme.primary.withOpacity(0.3),
        onDoubleTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ResultsPage(
                religionName: religionName,
                searchQuery: _controller.text,
                results: _flashcards,
              ),
            ),
          );
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 500),
          width: double.infinity,
          height: 180,
          decoration: BoxDecoration(
            color: isDarkMode ? Colors.grey[850] : Colors.brown[50],
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [
              BoxShadow(
                  color: Colors.black26,
                  blurRadius: 6,
                  offset: Offset(0, 4))
            ],
          ),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                religionName,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
